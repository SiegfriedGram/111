#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include "tcpsocket.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

private slots:
    void on_connectButton_clicked();

    void on_sendButton_clicked();

    void displayMessage(QString content);

private:
    Ui::MainWidget *ui;
    TcpSocket* socket;
};

#endif // MAINWIDGET_H

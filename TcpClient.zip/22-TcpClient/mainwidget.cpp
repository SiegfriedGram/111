#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QDebug>

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    socket = new TcpSocket(this);

    connect(socket, &TcpSocket::dealMessage,
            this, &MainWidget::displayMessage);

    ui->ipLineEdit->setText("127.0.0.1");
}

MainWidget::~MainWidget()
{
    delete ui;
}

// 发起连接
void MainWidget::on_connectButton_clicked()
{
    QString strIp = ui->ipLineEdit->text();
    quint16 port = ui->portLineEdit->text().toUInt();
    int ret = socket->connectToServer(strIp, port);
    if (ret)
    {
       qDebug() << "连接成功";
       ui->connectButton->setEnabled(false);
    }
    else
    {
        qDebug() << "连接失败";
    }
}

void MainWidget::on_sendButton_clicked()
{
    // 准备数据
    QString content = ui->sendLineEdit->text();

    // 发送
    socket->SendMessage(content);
}

void MainWidget::displayMessage(QString content)
{
    ui->recvLineEdit->setText(content);

}

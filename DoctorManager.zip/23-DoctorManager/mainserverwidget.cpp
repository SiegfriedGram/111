#include "mainserverwidget.h"
#include "ui_mainserverwidget.h"
#include "server.h"
#include <QDebug>

MainServerWidget::MainServerWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainServerWidget)
{
    ui->setupUi(this);
}

MainServerWidget::~MainServerWidget()
{
    delete ui;
}

// 自动连接
void MainServerWidget::on_startButton_clicked()
{
    // 获取服务器对象
    Server* ser = Server::getServerInstance();
    quint16 port = ui->portLineEdit->text().toUInt();
    ser->start(port);

    // 修改界面
    ui->startButton->setEnabled(false);
    ui->stopButton->setEnabled(true);
}

void MainServerWidget::on_stopButton_clicked()
{
    // 获取服务器对象
    Server* ser = Server::getServerInstance();
    ser->stop();

    // 修改界面
    ui->startButton->setEnabled(true);
    ui->stopButton->setEnabled(false);

}

void MainServerWidget::on_sendButton_clicked()
{
    // 准备好数据
    QString content = ui->sendLineEdit->text();

    // 获取服务器对象
    Server* ser = Server::getServerInstance();
    TcpSocket* socket = ser->getClients().at(0);

    // 发送
    socket->sendMessage(content);
}

static unsigned short ecgData[500];
void MainServerWidget::displayMessage(char *buffer)
{
    char serial[24] = {0};
    memcpy(serial, buffer, 24);
    memcpy(ecgData, buffer+24, 1000);
    delete[] buffer;
    qDebug() << serial;

}
